# PatchQuestions review progress — 7 November 2026

Status: in progress. Resume the 28-question review specified by the attached Pasted text.txt. Do not publish or submit anything. The user additionally requested persistent progress checkpoints.

## Completed evidence audit
- Read START_HERE.md, manuscript, README, all eight Python modules (benchmark, analyze, intervention, verify, replay, export_cases, cognitive_probe), notebook source and stored outputs, reference scores/summary/audit/intervention, context research review/protocol/requirements, cognitive study and research notes.
- Input ZIP SHA256: 6f2e3a897fa154177446f1c791c3cc20922b22c97d294ddd3a39c0a234e39e49.
- All 38 manifest payload hashes and lengths match.
- Fresh execution uses CPython 3.12.14 on Linux x86_64, /opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python. Source reference unchanged. Commands and wall times are in run_cpython_3_12_14/review_execution_log.json.
- Ran benchmark.py, analyze.py, intervention.py, verify.py, export_cases.py and cognitive_probe.py --check with -B. All exit 0.
- Fresh scores.csv (18,000 rows), summary.json, audit.json and intervention.json match reference bytes exactly. Forty newly exported matrix records match reference decompressed JSON exactly. Compressed gzip bytes can differ because gzip headers include time/path.
- All 750 named/masked entropy checks pass. This is not a Gemma experiment.
- Notebook has six embedded modules, each identical to standalone source. Notebook inspected, NOT run in a Jupyter kernel (nbclient/ipykernel absent); standalone equivalents were executed.
- Bundled 3.15.2 verification and historical 3.13.5 record are separate, not executed by this review.

## Working mathematical deductions — independent tests pending
- Identity leaf-count argument holds under uniform target weights and any target-blind final distribution supported on a consistent leaf, not only uniform final picks. Duplicate behavior does not invalidate identity proof, but affects behavioral utility and prior.
- Smallest mismatch with tie: 3 candidates, 2 queries, budget 1, hidden labels [0,0,1]; query 1 [0,1,0], query 2 [0,0,1]. Both give 2 identity leaves; first has behavioral agreement 2/3 vs 1. Strict leaf ranking mismatch uses 4 candidates: q1 [0,1,0,2], q2 [0,0,1,1], hidden [0,0,1,1]; 3 leaves gives .75 vs 2 leaves gives 1.
- Frugal recurrence appears correct for lexicographic max identity leaves/min expected questions with unit cost/uniform target weighting. Need explicit enumeration independent of implementation.
- All-query score is an upper reference for uniform-survivor selection under uniform targets; not a universal bound for selectors using extra prior/behavior knowledge. Need proof and counterexample.

## Sources accessed
- Official Kaggle paper overview/evaluation and rules retrieved by web search; deadline indexed as 12 Nov 2026 23:59 UTC / 13 Nov 04:59 PKT; 3,000 words, 5 equal rubric dimensions. Main-track entry not required. Draft must explicitly be submitted.
- Live browser overview opened but page content still loading on first snapshot; finish live overview/rules verification, then complete CUA summary.
- Primary LEARN2FIX paper https://arxiv.org/html/1912.07758v1 and xTestCluster https://arxiv.org/html/2207.11082v2 accessed; method reading still to deepen.
- InPaFer HTML failed; try abstract/PDF. CodeMonkeys, Ambig-SWE, Ask or Assume, SWE-Clar and reference patch assessment remain to verify directly.

## Remaining work
1. Independent random-path expectations and frugal/tree enumeration; explicit counterexamples.
2. Cross entropy × original/single/compound regex pools; count/entropy/answer-size costs; minimal descriptive sensitivity and redundancy analyses.
3. Recompute exact effect denominators and matched pilot classical baselines. Audit target-row permutation and secrecy/protocol behavior.
4. Complete primary literature verification and official live context.
5. Write all 28 answers: verdict/evidence/strongest counterargument/decisive check/severity. Include top five threats, literature table, deadline plan with at most two experiments, claim edits/abstract, and ten author-defense questions.
6. Save updated checkpoint after major steps and final review.

No Gemma, human study, repository repair experiment or leaderboard submission has been run. Do not invent such results or claim access to HARNESS_README, sample submission, model terms, active GPU quota or Colab units.


## Checkpoint 2 — independent audit complete
- reviewer_audit.py completed in 26.01 s under CPython 3.12.14. Source and output JSON/CSV are retained in reviewer_checks/.
- All 24,000 random-policy metric comparisons (750 episodes × 2 policies × 4 budgets × 4 metrics) pass, maximum absolute float discrepancy 1.776e-15. Independent enumeration used 1,015,896 terminal subsets/paths; exact Fraction arithmetic, no benchmark scoring recursion.
- Exhaustively tested all 4,096 binary 4-candidate × 3-query matrices at depths 0..3. Explicit tree enumeration confirmed maximum identity leaves and minimum question cost in all 16,384 combinations. Original verifier also passed its real-family depth-2 checks.
- Minimal 3-candidate/2-query/1-held-out counterexample and strict 4-candidate counterexample both executed through original evaluate(). See objective_counterexamples.json.
- Crossed pool × policy: at budget 3, entropy/frugal both original 30%, single 50%, compound 86.25%, on BOTH scoring suites. At budget 2 compound entropy 68.75%, frugal 75%; do not claim search never matters.
- Original regex universe and single probes have at most 2 distinct outcomes per query (max 1 bit). Compound probes have up to 8 (max initial entropy 2.54879494 bits). Average input character lengths: original universe 6.0179, singles 5, compounds 19; mean serialized answer characters 16.5982,17,22.0625. These are codepoint/serialization proxies, not annotation minutes/token counts.
- Budget-3 accuracy: random .5683128759984228, random informative .7631887749141841, diversity .848125, entropy .8527083333333333, tree/frugal .8547916666666666.
- Questions: entropy 1.8819791666666668, ordinary tree 2.265625, frugal 1.8644791666666667. Frugal saves .4011458333 / 2.265625 =17.705747% versus ordinary tree, but .0175 / 1.8819791667 =.929872% versus entropy.
- Whole budget-3 deterministic sweep (750 targets including regenerated matrices; median 3 noisy trials) entropy .22599 s, ordinary tree .25243 s, frugal .22498 s. NOT isolated policy time or robust scaling evidence. Do not claim expensive tree CPU cost is empirically demonstrated here.
- Hex has 36 configuration identities but only 30 joint query+heldout behavior classes. Other families have all configurations joint-distinct. Query class counts vary by split. Deduplication by hidden classes must remain evaluator-only.
- All-query uniform and evaluator-only Bayes/majority upper scores coincide in ALL 40 frozen matrices; macro .8572916667. Generic all-query uniform score is NOT universally optimal (3 candidates with one query outcome and hidden classes [A,A,B]: 5/9 vs fixed A 2/3). For this archive under uniform targets and no extra target information, the all-query reference is also a valid optimal bound. Do not blindly repeat the prompt's stronger skepticism.
- Leave-one-family-out tree/entropy margin is 0 without CSV and .238095 pp otherwise. Tree/random-informative margin remains 5.4347–10.4689 pp. These are sensitivity descriptions, not independent task confidence intervals.
- Target-weighted rather than family-macro accuracy: entropy87.6%, tree87.8667%; curated target weights not empirical bug prevalence.
- Matched 16-pair planned pilot exact classical means: random informative79.910099%, entropy87.5%, frugal87.5%; questions2.199487,1.8125,1.75. No Gemma sessions.
- protocol_audit.py additionally confirmed cognitive_probe.choose gives the same 3-question entropy success/question count as native benchmark on all750 frozen episodes. Five N=16 families reuse target rows13 and9 for original targets0and1. Targets differ only in last configuration axis.
- Actual protocol scoring boundary: replay.py wrap43 target10 shuffle2026; ask9 then pick4 (original candidate14). Answered input abcdefgh-z returns ['abcdefgh-z'] for target but ['abcdefgh-','z'] for pick; grader nevertheless returns heldout_exact:true. This follows declared heldout-only metric, is NOT corruption of classical results, but demands a separate consistency gate/metric before a model pilot.
- Live Kaggle overview AND complete paper rules read in browser7Nov. Deadline13Nov04:59PKT. User account page says draft Writeup ready for submission; no submission/change made. Rules already accepted before this review. No personal eligibility determination.
- Live required report sections, original/unpublished3000word cap, five equal criteria, resource category and optional main participation confirmed. HARNESS_README/sample/modelterms still not inspected. CUA completed and rules tab retained.
- Closest sources verified directly: InPaFer2020v2 abstract and approach PDF; LEARN2FIX2019v1 method; xTestCluster2024v2 method; RGT2021 publisher abstract/introduction; CodeMonkeys2025v2 selection methods; Ambig-SWE2026v3 abstract; Ask or Assume2026 ACL abstract; SWE-Clar2026v1 abstract. Settles2009 primary university report record; Nowak generalized binary search author-hosted paper/abstract found.

## Remaining after checkpoint 2
- Finish mathematical proof/write-up and review synthesis. No more broad experiment needed.
- Write full required eight-part review, all28answers with verdict/evidence/counterargument/check/severity; sources and at-most-two bounded future experiments; corrected paragraph/abstract;10defense questions.
- Update final checkpoint and save final review. Preserve all reference files. Do not submit/publish.
